#!/bin/bash

# Define the function Hello
Hello() {
    echo "Hello world"
}

# Call the function
Hello
