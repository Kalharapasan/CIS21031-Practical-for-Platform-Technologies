#!/bin/bash

# A function that displays the number of arguments passed to the script
# and the value of each argument
Arguments() {
  # Get the number of arguments passed to the script
  local num_args="$#"

  # Display the number of arguments
  echo "The number of arguments passed: $num_args"

  # Loop through each argument and display its value
  for (( i=1; i<=$num_args; i++ )); do
    echo "The $i argument is: ${!i}"
  done
}

# Call the Arguments function
Arguments "$@"

