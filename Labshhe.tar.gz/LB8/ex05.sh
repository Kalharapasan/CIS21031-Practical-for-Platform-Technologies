#!/bin/bash

var1='A'
var2='B'

echo "Before funtion call : "
echo "Var1 :$var1"
echo "Var2:$var2"

variable_scope(){
	var1='C'

	local var1='D'

	var2='E'

	echo "Inside funtion"
	echo "Var1 : $var1"
	echo "Var2 : $var2"
}

variable_scope

echo "After funtion call : "
echo "Var1 :$var1"
echo "Var2:$var2"

