#!/bin/bash

Arguments(){

	
	local num="$#"
	Arg1=$1
	Arg2=$2


	echo "The number of Arguments passed : $num"
	echo "The frist argument is :$Arg1"
	echo "The second argument is :$Arg2"




	
}

Arguments "Apple " "Banana"
