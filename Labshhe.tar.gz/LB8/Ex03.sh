#!/bin/bash

# Define the function Add_Val
Add_Val() {
    # Prompt the user to enter a number
    echo "Enter a number:"
    read number

    # Add 20 to the entered number
    result=$((number + 20))

    # Print the final value
    echo "Final value: $result"
}

# Call the function
Add_Val
