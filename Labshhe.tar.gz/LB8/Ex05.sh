#!/bin/bash

# Define global variables
var1='A'
var2='B'

echo "Before function call:"
echo "var1: $var1"
echo "var2: $var2"

# Define the function variable_scope
variable_scope() {
    # Modify the global variable var1
    var1='C'
    
    # Set var1 as a local variable and assign 'D' to it
    local var1='D'
    
    # Modify the global variable var2
    var2='E'
    
    # Print the values of var1 and var2 within the function
    echo "Inside function:"
    echo "var1: $var1"
    echo "var2: $var2"
}

# Call the function
variable_scope

# Print the values of var1 and var2 outside the function
echo "After function call:"
echo "var1: $var1"
echo "var2: $var2"
