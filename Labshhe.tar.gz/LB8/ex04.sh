#!/bin/bash

Add_val(){

	echo "Enter a number :"
	read number

	result=$((number +20))

	echo "final value :$result"
}
Add_val