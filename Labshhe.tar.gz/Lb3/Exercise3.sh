#!/usr/bin/bash

Day=("Monday" "Tuesday" "Wedneday" "Thursday")

echo "Frist day of the week :${Day[0]}"
echo "Second day of the week :${Day[1]}"
echo "All day of the week :${Day[@]}"

Day+="Friday"
echo "Second day of the week :${Day[@]}"

Day[1]="Sunday"
echo "Second day of the week :${Day[1]}"

echo "Last day of the week :${Day[-1]}"

