#!/usr/bin/bash

Cours="Platfom Technolog"

echo "Cours : $Cours"

UserName=$(whoami)
HostName=$(hostname)
CurrentDirectory=$(pwd)
UserHomeDirectory=$(echo ~)


echo "User Name : $UserName"
echo "Host Name : $HostName"
echo "Current Directory : $CurrentDirectory"
echo "User Home Directory : $UserHomeDirectory"
