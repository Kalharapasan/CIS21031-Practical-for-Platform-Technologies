#!/usr/bin/bash

echo "CIS21031 LabSheet 03 -Introduction to shell Scripting"
massage="CIS21031 LabSheet -Introduction to shell Scripting"

value1=6
value2=6.75
value3="Technology"

echo "value1 :$value1"
echo "value2 :$value2"
echo "value3 :$value3"

hostname=$(hostname)
echo "The script is running on $hostname"