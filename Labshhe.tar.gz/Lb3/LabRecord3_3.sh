#!/bin/bash

# LabRecord3_3.sh

# i. Create an array variable called ‘Fruits’ and add four values to it
Fruits=("Apple" "Orange" "Grapes" "Banana")

# ii. Print the first element of the array
echo "First fruit in the array: ${Fruits[0]}"

# iii. Print all the elements in the array
echo "All fruits in the array: ${Fruits[@]}"

# iv. Add another element called “Watermelon” as the last element and print that element
Fruits+=("Watermelon")
echo "Added fruit: ${Fruits[4]}"

# v. Print the elements starting from index 2
echo "Fruits starting from index 2: ${Fruits[@]:2}"

# vi. Change the value of the second element to “Pineapple”
Fruits[1]="Pineapple"
echo "Modified second fruit: ${Fruits[1]}"

# vii. Get the number of elements in the array
echo "Number of fruits in the array: ${#Fruits[@]}"

# viii. Delete last before element in the array
unset 'Fruits[${#Fruits[@]}-2]'

# Print the updated array
echo "Fruits after deleting last before element: ${Fruits[@]}"
