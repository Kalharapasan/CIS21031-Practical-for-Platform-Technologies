#!/usr/bin/bash

echo "Wlcome $LOGNAME"
echo "You are working on $SHELL shell"
echo "You are currently working on $(pwd) directory"
echo "You are using $OSTYPE operating system"