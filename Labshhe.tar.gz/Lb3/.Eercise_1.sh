#!/usr/bin/bash

echo "Wlcome $LOGNAME"