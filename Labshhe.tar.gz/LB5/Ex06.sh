#!/bin/bash

# Prompt the user to enter two strings
echo "Enter the first string:"
read str1

echo "Enter the second string:"
read str2

# Check if the strings are equal or not
if [ "$str1" == "$str2" ]; then
    echo "The two strings are equal."
else
    echo "The two strings are not equal."
fi

# Check if the first string is empty
if [ -z "$str1" ]; then
    echo "The first string is empty."
else
    echo "The first string is not empty."
fi

# Check if the second string is empty
if [ -z "$str2" ]; then
    echo "The second string is empty."
else
    echo "The second string is not empty."
fi
