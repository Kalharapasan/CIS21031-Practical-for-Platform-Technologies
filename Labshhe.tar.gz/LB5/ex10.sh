#!/bin/bash

echo "Enter you frist String:"
read str1

echo "Enter you second String:"
read str2

if [ "$str1" == "$str2" ]; then
	echo "Frist String and second String to equel"
else
	echo "Frist String and second String not to equel"
fi