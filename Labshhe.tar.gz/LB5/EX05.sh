#!/bin/bash

# Prompt the user to enter the student's marks
echo "Enter the student's marks:"
read marks

# Check if the student has passed or failed
if [ "$marks" -ge 40 ]; then
    echo "The student has passed."
else
    echo "The student has failed."
fi
