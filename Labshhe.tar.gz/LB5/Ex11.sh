#!/bin/bash

# Create a folder in the current working directory
mkdir -p my_folder

# Navigate to the newly created folder
cd my_folder

# Create the file
touch file_ICTXXX.sh

# Check if the file exists
if [ -e "file_ICTXXX.sh" ]; then
    echo "file_ICTXXX.sh exists."
else
    echo "file_ICTXXX.sh does not exist."
fi

# Remove the file
rm file_ICTXXX.sh

# Check if the file exists after removal
if [ -e "file_ICTXXX.sh" ]; then
    echo "file_ICTXXX.sh exists."
else
    echo "file_ICTXXX.sh does not exist."
fi
