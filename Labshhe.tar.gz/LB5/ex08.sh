#!/bin/bash

directry="/Desktop/SEU.IS.20.ICT.084"

if [ -d "$HOME$directry" ]; then
	echo "Directory hass exister"
	#statements
else
	echo "Directory hass not exister"
	mkdir -p "$HOME$directry"
fi