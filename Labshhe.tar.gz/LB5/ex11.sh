#!/bin/bash

echo "Enter you Directroy Name :"
read dire

fille="ICT461.sh"

if [ -d "$dire" ]; then
	if [ -e "$fille" ]; then
		cd $dire
		echo "$fille has exists in Directroy "
	else
		cd $dire
		echo "$fille has not exists not in Directroy "
		touch "$fille"	

	$rm "$fille"

	fi
else
	mkdir "$dire"
	cd $dire
	touch "$fille"
	echo "$dire directroy and $fille fille has create  in Directroy "


fi