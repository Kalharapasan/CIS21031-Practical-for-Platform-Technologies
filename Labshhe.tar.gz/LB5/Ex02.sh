#!/bin/bash

echo "Enter you frist Number : "
read num1

echo "Enter you second Number : "
read num2

if [ "$num1" -gt "$num2" ];then
	echo "You number 01 gerter then number 02"
else
	echo "You number 01 not gerter then number 02"
fi
