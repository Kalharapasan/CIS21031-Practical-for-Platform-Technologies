#!/bin/bash

echo "Enter you number :"
read num

if (($num%2 == 1)) ; then
	echo "$num Number is odd Number"
else
	echo "$num Number is even Number"
fi


