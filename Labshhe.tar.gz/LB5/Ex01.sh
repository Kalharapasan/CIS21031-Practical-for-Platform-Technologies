#!/usr/bin/bash

num1=10
num2=30

if [ "$num1" -eq "$num2"  ];then
	echo "The $num1 is equal to $num2 "
else
	echo "The $num1 is not equal to $num2 "
fi
