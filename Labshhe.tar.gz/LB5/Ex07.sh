#!/bin/bash

# Prompt the user to enter a filename
echo "Enter the filename:"
read filename

# Check if the file exists
if [ -e "$filename" ]; then
    echo "The file $filename exists."

    # Check for read permission
    if [ -r "$filename" ]; then
        echo "You have read permission for $filename."
    else
        echo "You do not have read permission for $filename."
    fi

    # Check for write permission
    if [ -w "$filename" ]; then
        echo "You have write permission for $filename."
    else
        echo "You do not have write permission for $filename."
    fi

    # Check for execute permission
    if [ -x "$filename" ]; then
        echo "You have execute permission for $filename."
    else
        echo "You do not have execute permission for $filename."
    fi

    # Check if the file is a directory
    if [ -d "$filename" ]; then
        echo "$filename is a directory."
    else
        echo "$filename is not a directory."
    fi

else
    echo "The file $filename does not exist."
fi
