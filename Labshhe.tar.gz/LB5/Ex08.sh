#!/bin/bash

# Define the directory path based on your Registration Number
directory="/Desktop/SEU.IS.20.ICT.084"

# Check if the directory exists
if [ -d "$HOME$directory" ]; then
    echo "Machine has a directory $directory."
else
    echo "Directory $directory does not exist. Creating the directory..."
    mkdir -p "$HOME$directory"
    echo "Directory $directory has been created."
fi
