#!/bin/bash

# Prompt the user to enter a number
echo "Enter a number:"
read number

# Check if the number is positive, negative, or neither
if [ "$number" -gt 0 ]; then
    echo "$number is a positive number."
elif [ "$number" -lt 0 ]; then
    echo "$number is a negative number."
else
    echo "Neither positive nor negative."
fi
