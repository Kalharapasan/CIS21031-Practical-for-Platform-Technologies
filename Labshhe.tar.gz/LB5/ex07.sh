#!/usr/bin/bash

echo "Enter you file name :"
read file

if [ -e "$file" ]; then
	
	if [[ -r "$file" ]]; then
		echo "Fille is readable"
	else
		echo "Fille is not readable"
	fi
	if [[ -w "$file" ]]; then
		echo "Fille is writable"
	else
		echo "Fille is not writable"

	fi
	if [[  -x "$file" ]]; then
		echo "Fille is executable"
	else
		echo "Fille is not executable"
	fi

else
	echo "Fille is not exists"
fi

