#!/bin/bash

# Prompt the user to enter a month
echo "Enter a month (e.g., January, February, ...):"
read month

# Check the number of days in the entered month using case statement
case "$month" in
    "January" | "March" | "May" | "July" | "August" | "October" | "December")
        echo "31 days"
        ;;
    "April" | "June" | "September" | "November")
        echo "30 days"
        ;;
    "February")
        echo "28 or 29 days"
        ;;
    *)
        echo "Invalid month."
        ;;
esac
