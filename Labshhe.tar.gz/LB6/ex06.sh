#!/bin/bash

echo "Select Option"
echo "a.Registration"
echo "b.File Operations 1"
echo "c.File Operations 2"
echo "d.Exit"

read option

case "$option" in
	"a" )
		
		echo "Enter you Registration Number"
		read reg
		echo "Enter you Password"
		read -s pass
		echo  "Enter tou confirm Password"
		read -s cpass

		if [ "$pass" == "$cpass" ]; then
			echo "Password mathing"
		else
			echo "Password do not mathing"
			echo "Enter tou confirm Password"
			read -s cpass
			if [ "$pass" == "$cpass"  ]; then
				echo "Password mathing"
			else
				echo "Password do not mathing"
			fi
		fi

		;;
	"b")
		
		echo "show hidden file ext files and .sh files:" 
		ls -al 
		;;

	"c")
		echo "Create LB6 directory and test1.sh fille in directory "
		mkdir LB6
		touch "LB6/test1.sh"
		;;
	"d")
		echo "Exit system" 
		;;

	*)
		echo "Invalid Input " 
		;;

esac
