#!/bin/bash

# Prompt the user to input whether they are a student or not
echo "Are you a student? (yes/no)"
read is_student

# Check the user's input using case statement
case "$is_student" in
    "yes")
        echo "You are a student."
        ;;
    "no")
        echo "You are not a student."
        ;;
    *)
        echo "Invalid input. Please enter 'yes' or 'no'."
        ;;
esac
