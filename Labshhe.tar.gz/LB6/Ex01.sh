#!/bin/bash

# Prompt the user to enter a number
echo "Enter a number:"
read num

# Define the range limits
min=10
max=50

# Check if the number is within the range
if [ "$num" -ge "$min" ] && [ "$num" -le "$max" ]; then
    echo "$num is within the range ($min-$max)."
else
    echo "$num is outside the range ($min-$max)."
fi
