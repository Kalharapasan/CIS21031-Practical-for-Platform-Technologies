#!/bin/bash

echo "Enter you number :"
read num1

min=40
max=100

if [ "$num1" -gt "$min" ] && [ "$num1" -lt "$max" ]; then
	echo "You number is in range"
else
	echo "You number is not in range"

fi