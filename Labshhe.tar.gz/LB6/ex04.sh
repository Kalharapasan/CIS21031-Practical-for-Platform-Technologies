#!/bin/bash

echo "Are you student (Yes/No) : "
read answer

case "$answer" in
	"Yes")
		echo "you  are student" 
		;;
	"No")
		echo "you  are not student"
		;;
	*)
		echo "Invalid input .plese enter Yes or NO"
		;;


esac