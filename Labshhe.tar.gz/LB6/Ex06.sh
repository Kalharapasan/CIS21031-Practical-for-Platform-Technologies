#!/bin/bash

# Display the options list
echo "Select an option:"
echo "a. Registration"
echo "b. File Operations 1"
echo "c. File Operations 2"
echo "d. Exit"

# Prompt the user to enter an option
read Option

# Process the selected option
case "$Option" in
    "a")
        # Registration
        echo "Enter Registration Number:"
        read reg_num

        echo "Enter Password:"
        read password

        echo "Confirm Password:"
        read confirm_password

        # Check if password and confirm password match
        if [ "$password" == "$confirm_password" ]; then
            echo "Passwords Match."
        else
            echo "Passwords do not Match."
            echo "Re-enter Confirm Password:"
            read confirm_password
            if [ "$password" == "$confirm_password" ]; then
                echo "Passwords Match."
            else
                echo "Passwords do not Match."
            fi
        fi
        ;;
    "b")
        # File Operations 1
        echo "Hidden files:"
        ls -a | grep "^\."
        
        echo "Text files and .sh files:"
        ls -l | grep -E '\.txt$|\.sh$' | awk '{print $9}'
        ;;
    "c")
        # File Operations 2
        mkdir -p Lab6
        touch Lab6/test1
        echo "Directory 'Lab6' and file 'test1' created."
        ;;
    "d")
        # Exit
        echo "Exiting..."
        exit 0
        ;;
    *)
        # Invalid option
        echo "Invalid option! Try again."
        ;;
esac
