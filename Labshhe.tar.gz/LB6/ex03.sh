#!/bin/bash

echo "Enter you subject 1 Marks : "
read mark1

echo "Enter you subject 2 Marks : "
read mark2

echo "Enter you subject 3 Marks : "
read mark3

echo "Enter you subject 4 Marks : "
read mark4

echo "Enter you subject 5 Marks : "
read mark5


total=$((mark1+mark2+mark3+mark4+mark5))
average=$((total/5))

if [ "$average" -ge 90 ]; then
	echo "Frist division"
elif [ "$average" -le 86 ] && [ "$average" -ge 60 ]; then
	echo "Second Upper division"
elif [ "$average" -le 59 ] && [ "$average" -ge 40 ]; then
	echo "Second Lower division"
else
	echo "File"

fi