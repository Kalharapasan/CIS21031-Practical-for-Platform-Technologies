#!/bin/bash

# Prompt the user to enter marks for five subjects
echo "Enter marks for Subject 1:"
read sub1

echo "Enter marks for Subject 2:"
read sub2

echo "Enter marks for Subject 3:"
read sub3

echo "Enter marks for Subject 4:"
read sub4

echo "Enter marks for Subject 5:"
read sub5

# Calculate the average marks
total_marks=$((sub1 + sub2 + sub3 + sub4 + sub5))
average_marks=$((total_marks / 5))

# Determine the division based on average marks
if [ "$average_marks" -ge 90 ]; then
    echo "First division"
elif [ "$average_marks" -ge 60 ] && [ "$average_marks" -le 89 ]; then
    echo "Second Upper division"
elif [ "$average_marks" -ge 40 ] && [ "$average_marks" -le 59 ]; then
    echo "Second Lower division"
else
    echo "Fail"
fi
