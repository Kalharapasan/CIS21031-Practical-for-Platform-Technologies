#!/bin/bash

echo "Enter you month :"
read month

case "$month" in
	"January" | "March" | "May" | "July" | "August" | "October" | "December")
		echo "31 day"
		;;
	 "April" | "June" | "September" | "November")
		echo "30 day"
		;;
	 "February")
		echo "28 or 29 day"
		;;
	*)
		echo "Invalid month"
		;;

esac