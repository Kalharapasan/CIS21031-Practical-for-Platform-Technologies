#!/bin/bash

# i. Define two variables a and b and assign values 8 and 10, respectively
a=8
b=10

# ii. Print the two variables
echo "a = $a"
echo "b = $b"

# iii. Then print sum of the two variables
sum=$(expr $a + $b)
echo "Sum of a and b: $sum"

# iv. Next print a MOD b
mod=$(expr $a % $b)
echo "a MOD b: $mod"

# v. Compute a minus b and save it to another variable ‘z’. Print ‘z’
z=$(expr $a - $b)
echo "a minus b: $z"

# vi. Print a * b
mul=$(expr $a \* $b)
echo "a * b: $mul"

# vii. Finally, print a / b
div=$(expr $a / $b)
echo "a / b: $div"
