#!/bin/bash

# a) Addition
result_add=$((5 + 6))
echo "5 + 6 = $result_add"

# b) Subtraction
result_sub=$((14 - 8))
echo "14 - 8 = $result_sub"

# c) Multiplication
result_mul=$((4 * 5))
echo "4 * 5 = $result_mul"

# d) Division
result_div=$((20 / 4))
echo "20 / 4 = $result_div"

# e) Modulus
result_mod=$((20 % 3))
echo "20 % 3 = $result_mod"
