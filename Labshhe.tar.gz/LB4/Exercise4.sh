#!/bin/bash

# a) Declare a variable called a and make its value as “Hello World”
a="Hello World"

# b) Print the length of a
length_a=${#a}
echo "Length of a: $length_a"

# c) Declare a variable called b and make its value as ‘1234’
b='1234'

# d) Print the length of b
length_b=${#b}
echo "Length of b: $length_b"
