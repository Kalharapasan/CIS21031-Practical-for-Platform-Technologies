#!/bin/bash

# Print "What is your first name?" and get user input
echo "What is your first name?"
read firstName

# Print "What is your degree program?" and get input from user
echo "What is your degree program?"
read degree

# Request for the Registration Number
echo "Please enter your Registration Number:"
read regNumber

# Prompt the user to enter a User name
echo "Please enter a username:"
read userName

# Request the user to enter a password (The password should not be visible to any users)
echo "Please enter a password:"
read -s password

# Print the message
echo "Hello $firstName. Your Registration number is $regNumber."
echo "You are reading $degree degree program and your username is $userName."
