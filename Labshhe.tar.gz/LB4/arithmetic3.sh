#!/bin/bash

# i. Initialize that 7+3 is r, and print the value of r
(( r = 7 + 3 ))
echo "r = $r"

# ii. Check whether are you able to get the same output by spacing it out
(( r_spaced = 7 +     3 ))
echo "r_spaced = $r_spaced"

# iii. Assign a variable called n and perform the summation of r+5, and the output for n
(( n = r + 5 ))
echo "n = $n"

# iv. Increment the value of n by 1 and display the output
(( n++ ))
echo "n incremented by 1 = $n"

# v. Increment the value of n by 3 and display the output
(( n += 3 ))
echo "n incremented by 3 = $n"
