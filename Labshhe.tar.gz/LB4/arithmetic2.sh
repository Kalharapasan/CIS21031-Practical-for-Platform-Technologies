#!/bin/bash

# i. Initialize that k=2+4
let "k = 2 + 4"
echo "k = $k"

# ii. Print the value of k
echo "Value of k: $k"

# iii. Use quotes and again initialize k=3+6
let "k = 3 + 6"
echo "k = $k"

# iv. Next, print the value of k
echo "Value of k: $k"

# v. Increment the value of k by 1 and print its value
let "k += 1"
echo "k incremented by 1 = $k"

# vi. Find the product of 5*5 by initializing it to a variable called a, and then print its value
let "a = 5 * 5"
echo "a = $a"
