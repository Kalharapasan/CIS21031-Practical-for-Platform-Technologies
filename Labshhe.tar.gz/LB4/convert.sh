
#!/bin/bash

# i. Print a number from user input command
echo "Enter the number in feet:"
read feet

# ii. Convert this number into inches and feet
inches=$(echo "$feet * 12" | bc)
echo "$feet feet is equal to $inches inches."

feet_converted=$(echo "scale=2; $inches / 12" | bc)
echo "$inches inches is equal to $feet_converted feet."
