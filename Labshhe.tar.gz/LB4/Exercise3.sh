#!/bin/bash

# a) Define three variables a, b, and c and assign values 2, 5, 9 respectively
a=2
b=5
c=9

# b) Print the three variables
echo "a = $a"
echo "b = $b"
echo "c = $c"

# c) Print “c % b equals to <<value of c MOD b >>”
result_mod=$(expr $c % $b)
echo "c % b equals to $result_mod"

# d) Compute ‘c minus b’ and save it to another variable ‘P’. Print ‘P’
P=$(expr $c - $b)
echo "c minus b equals to $P"

# e) Print “a * c equals to <<value of a * c >>”
result_mul=$(expr $a \* $c)
echo "a * c equals to $result_mul"

# f) Finally, print “c/b equals to << value of c/b >>”
result_div=$(expr $c / $b)
echo "c/b equals to $result_div"
