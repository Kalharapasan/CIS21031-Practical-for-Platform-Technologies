#!/bin/bash

k=$((2+4))
echo "K value :$k"

k=$((3+6))
echo "K value :$k"

k=$(($k+1))
echo "K value :$k"

a=$((5*5))
echo "a value :$a"
