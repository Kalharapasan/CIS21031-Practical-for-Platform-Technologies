#!/bin/bash

# Ask user for their name
echo "What is your name?"
read name

# Print the message 
echo "It's nice to meet you $name."
