#!/bin/bash

# Initialize x=5+6
let "x=5+6"

# Print the value of x
echo "Value of x: $x"

# Increment the value of x by 1 and print its value
let "x=x+1"
echo "Incremented value of x: $x"

# Print the value of x
echo "Value of x: $x"

# Initialize a=14, b=8 and print the value of y=a-b
a=14
b=8
let "y=a-b"
echo "Value of y: $y"
n
# Decrement the value of y by 2 and print its value
let "y=y-2"
echo "Decremented value of y: $y"

# Find the product of 4*5 by initializing it to a variable called z, and then print its value
let "z=4*5"
echo "Value of z: $z"
