#!/usr/bin/bash

echo "Enter you feed convet to incres : "
read feed

((incres=$feed*12))
echo "You convet value is:$incres"