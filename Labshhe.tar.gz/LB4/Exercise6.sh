#!/bin/bash

# Ask user for login details
echo "Enter your username:"
read username

# Ask user for password (The password will be hidden)
echo "Enter your password:"
read -s password

# Print the message
echo "Thank you $username, you have now entered your login details."
