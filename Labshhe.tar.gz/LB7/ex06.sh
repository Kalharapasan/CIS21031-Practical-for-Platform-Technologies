#!/bin/bash

echo "Enter a number"
read number

reve_number=""
while [ "$number" -gt 0 ]; do
	digit=$((number%10))

	reve_number=${reve_number}${digit}

	number=$((number/10))
done
echo "Reversed number : $reve_number"