#!/bin/bash

# Your index number
index_number="YourIndexNumberHere"

# Print your index number five times using for loop
for ((i = 0; i < 5; i++)); do
    echo "$index_number"
done
