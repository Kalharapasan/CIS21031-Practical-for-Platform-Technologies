#!/bin/bash

# Prompt the user to enter a number
echo "Enter a number:"
read number

# Initialize variable to store the reversed number
reversed_number=""

# Loop to reverse the digits of the number
while [ "$number" -gt 0 ]; do
    # Get the last digit of the number
    digit=$((number % 10))
    
    # Append the digit to reversed_number
    reversed_number="${reversed_number}${digit}"
    
    # Remove the last digit from the number
    number=$((number / 10))
done

# Display the reversed number
echo "Reversed number: $reversed_number"
