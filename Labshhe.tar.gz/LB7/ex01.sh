#!/bin/bash

x=0
while [ "$x" -lt 10 ]; do
	echo "X is : $x"
	((x++))
done