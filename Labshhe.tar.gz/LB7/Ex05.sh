#!/bin/bash

# Define the number of lines for the pattern
lines=5

# Outer loop to iterate through each line
for ((i = 1; i <= lines; i++)); do
    # Inner loop to print '*' for each line
    for ((j = 1; j <= i; j++)); do
        echo -n "* "
    done
    # Move to the next line after printing each line of the pattern
    echo
done
