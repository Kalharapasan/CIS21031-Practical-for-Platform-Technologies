#!/bin/bash

# Prompt the user to enter a number
echo "Enter a number:"
read number

# Initialize sum variable
sum=0

# Loop to calculate sum of digits
while [ "$number" -gt 0 ]; do
    # Get the last digit of the number
    digit=$((number % 10))
    
    # Add the digit to sum
    sum=$((sum + digit))
    
    # Remove the last digit from the number
    number=$((number / 10))
done

# Display the sum of digits
echo "Sum of digits: $sum"
