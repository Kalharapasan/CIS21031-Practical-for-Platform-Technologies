#!/bin/bash

echo "Enter you number"
read num

sum=0

while [ "$num" -gt 0  ]; do
	digite=$((num/10))
	sum=$((sum+digite))
	num=$((num/10))
done

echo "Sum of digite : $sum"