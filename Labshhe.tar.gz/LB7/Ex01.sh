#!/bin/bash

# Initialize a variable to store the starting number
num=0

# Print numbers less than 10 using while loop
while [ "$num" -lt 10 ]; do
    echo "$num"
    # Increment the number
    ((num++))
done
