#!/bin/bash

# Your index number
index_number="YourIndexNumberHere"

# Print your index number five times using for loop
for i in {1..5}; do
    echo "$index_number"
done
