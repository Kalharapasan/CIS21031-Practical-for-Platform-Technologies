#!/bin/bash

for (( i = 0; i < 5; i++ )); do
	echo "SEU/IS/20/ICT/084"
done