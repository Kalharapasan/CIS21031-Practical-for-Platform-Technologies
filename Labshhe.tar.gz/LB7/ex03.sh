#!/bin/bash


for n in {1..5}; do
	echo "SUE/IS/20/ICT/084"
done