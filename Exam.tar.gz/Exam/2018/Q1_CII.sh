#!/bin/bash

# Function to add ten integer values to a file
add_integers_to_file() {
    echo "Please enter ten integer values:"
    for i in {1..10}; do
        read num
        echo $num >> $1
    done
}

# Function to add write permission and add ten integer values to a file
add_write_permission_and_values() {
    chmod +w $1
    add_integers_to_file $1
}

# Function to display file contents line by line
display_file_contents() {
    echo "File contents:"
    while IFS= read -r line; do
        echo "$line"
    done < $1
}

# Function to append ten random integer values between 20 to 200 to a file
append_random_integers() {
    for i in {1..10}; do
        echo $((RANDOM % 181 + 20)) >> $1
    done
}

# Function to find the sum of all integers in a file
sum_integers_in_file() {
    local sum=0
    while IFS= read -r line; do
        sum=$((sum + line))
    done < $1
    echo "Sum of all integers in the file: $sum"
}

# Main script
file="file_for_partA.txt"

# Check if the file is writable
if [[ -w $file ]]; then
    add_integers_to_file $file
else
    read -p "The file is not writable. Do you want to add write permission? (YES/NO): " choice
    case $choice in
        [yY]|[yY][eE][sS])
            add_write_permission_and_values $file
            ;;
        [nN]|[nN][oO])
            echo "No content was written to the file."
            ;;
        *)
            echo "Invalid choice."
            ;;
    esac
fi

# Display file contents
display_file_contents $file

# Append ten random integer values to the file
append_random_integers $file

# Find the sum of all integers in the file
sum_integers_in_file $file
