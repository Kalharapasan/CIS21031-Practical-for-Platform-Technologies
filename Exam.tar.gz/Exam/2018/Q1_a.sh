s#!/bin/bash
validate_password(){

	local password=$1
	local lowercase=0
	local uppercase=0
	local number_has=0
	local len=${#password}


	if [ "$len" -lt 8 ]; then
		for (( i = 0; i <len; i++ )); do
		
			char =${password :$i:1}
			if [ $char =~ [a-z] ] ; then
				lowercase=1
			fi

			if [[ $char =~ [A-z] ]]; then
				#statements
				uppercase=1
			fi
			if [[ $char =~ [0-9] ]]; then
				#statements
				number_has=1
			fi
		done

		if [ "$lowercase" -lt 0 ] || [ "$uppercase" -lt 0 ] || [ "$number_has" -lt 0 ]; then
			echo "Password is strong"
			return 0
		else
			echo "Password hale length 8 but password weak password"
			return 1
		fi
	fi
	return 0	

}

echo "Enter file name"
read filename
echo "Enter password"
read -s password

if validate_password "$password" ; then
	#statements
	echo "Creating file $filename.txt"
	touch "$filename.txt"
else
	echo "File not created due to weak password"
fi