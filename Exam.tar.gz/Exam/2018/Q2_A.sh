#!/bin/bash

# Function to read ten integers from the user
read_integers() {
    echo "Please enter ten integer values:"
    for i in {1..10}; do
        read num
        integers+=($num)
    done
}

# Function to sort and display the integers
sort_integers() {
    sorted_integers=($(printf '%s\n' "${integers[@]}" | sort -n))
    echo "Sorted list of integers: ${sorted_integers[*]}"
}

# Function to find the smallest and largest integers
find_min_max() {
    min=${integers[0]}
    max=${integers[0]}
    for num in "${integers[@]}"; do
        if (( num < min )); then
            min=$num
        fi
        if (( num > max )); then
            max=$num
        fi
    done
    echo "Smallest integer: $min"
    echo "Largest integer: $max"
}

# Function to find duplicated integers
find_duplicates() {
    duplicates=($(printf '%s\n' "${integers[@]}" | sort | uniq -d))
    if [[ ${#duplicates[@]} -eq 0 ]]; then
        echo "No duplicated integers found."
    else
        echo "Duplicated integers: ${duplicates[*]}"
    fi
}

# Function to calculate the sum of digits of the integers
sum_digits() {
    local sum=0
    for num in "${integers[@]}"; do
        while (( num > 0 )); do
            digit=$(( num % 10 ))
            sum=$(( sum + digit ))
            num=$(( num / 10 ))
        done
    done
    echo "Sum of digits: $sum"
}

# Main script
integers=()

while true; do
    echo "Menu:"
    echo "1. Read ten integers"
    echo "2. Sort and display integers"
    echo "3. Find smallest and largest integers"
    echo "4. Find duplicated integers"
    echo "5. Calculate sum of digits"
    echo "6. Exit"
    read -p "Enter your choice: " choice

    case $choice in
        1)
            read_integers
            ;;
        2)
            sort_integers
            ;;
        3)
            find_min_max
            ;;
        4)
            find_duplicates
            ;;
        5)
            sum_digits
            ;;
        6)
            echo "Exiting."
            exit 0
            ;;
        *)
            echo "Invalid choice. Please try again."
            ;;
    esac
    echo "-----------------------------------------"
done
