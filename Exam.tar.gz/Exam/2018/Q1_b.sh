#!/bin/bash

chek_file (){

	local directory=$1
	local file=$2


	

	if [[ -d "$directory" ]]; then
		echo "directory  has  exists"
		cd $directory
		if [[ -e "$fille"  ]]; then
			
			if [[ -r "$file" ]]; then
				echo "Fille is readable"
			else
				echo "Fille is not readable"
			fi

			if [[ -w "$file" ]]; then
				#statements
				echo "Fille is writable"
			else
				echo "Fille is not writable"
			fi

			echo "Fille is executable"

			if [[ -s "$file" ]]; then
				echo "Fille has size gerate than 0"
			else
				echo "Fille has not size gerate than 0"
			fi

			if [[  -c "$file" ]]; then
				echo "Fille is a character special file"
			else
				echo "Fille is a not character special file"
			fi
		else
			echo "Fille is executable"

		fi
	else
		echo "directory  has not exists"

	fi




}

echo "Enter directory name :"
read  directory
echo "Enter Fille name :"
read fille

chek_file "$directory" "$fille"