#!/bin/bash

# Function to calculate factorial recursively
factorial() {
    if (( $1 <= 1 )); then
        echo 1
    else
        echo $(( $1 * $(factorial $(( $1 - 1 ))) ))
    fi
}

# Function to convert decimal to binary recursively
decimal_to_binary() {
    if (( $1 == 0 )); then
        echo -n "0"
    elif (( $1 == 1 )); then
        echo -n "1"
    else
        decimal_to_binary $(( $1 / 2 ))
        echo -n $(( $1 % 2 ))
    fi
}

# Main script
echo "Menu:"
echo "1. Calculate factorial"
echo "2. Convert decimal to binary"
echo "3. Exit"

while true; do
    read -p "Choose an option: " choice

    case $choice in
        1)
            read -p "Enter a number to calculate factorial: " num
            result=$(factorial $num)
            echo "Factorial: $result"
            ;;
        2)
            read -p "Enter a decimal number to convert to binary: " num
            result=$(decimal_to_binary $num)
            echo "Binary representation: $result"
            ;;
        3)
            echo "Exiting program."
            exit 0
            ;;
        *)
            echo "Invalid option. Please choose again."
            ;;
    esac
    echo
done
