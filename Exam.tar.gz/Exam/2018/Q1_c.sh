#!/bin/bash

integer_to_file(){
	echo "Please enter ten integer values "
	for i in {1..10}; do

		echo "Enter number $i :"
		read num
		echo $num>>$1
	done
}

write_value_file(){
	chmod +w $1
	integer_to_file $1

}

diplay_file_contents(){
	echo "File contents"
	while IFS= read -r line; do
		echo "$line"
	done<$1
}

random_integers(){
	for i in {1..10}; do
		echo $((RANDOM %181+20))>>$1
	done
}

integer_in_file(){
	local sum=0
	while IFS= read -r line ;do
		sum=$((sum+line))
	done <$1
	echo "Sum of all integer in the file : $sum" 
}

file="Q1_c.txt"

if [  -w $file ] ;then
	integer_to_file $file
else
	read -p "The file is not writable.do you want to add write permission ? (1.Yes or 2.No)" choice

	case $choice in
		"1" )
			write_value_file $file
			;;

		"2")
			
			echo "No content was written to the file"
			;;
		*)
			echo "Invalid input"
			;;
	esac

fi


diplay_file_contents $file

random_integers $file 

integer_in_file $file 