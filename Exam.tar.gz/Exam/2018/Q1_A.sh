0 #!/bin/bash

# Function to validate password
validate_password() {
    local password=$1
    local len=${#password}
    local has_lowercase=0
    local has_uppercase=0
    local has_number=0

    # Check password length
    if [ "$len" -lt 8 ]; then
        echo "Weak password: Password length should be minimum of 8 characters."
        return 1
    fi

    # Check for lowercase, uppercase, and numeric characters
    for (( i=0; i<len; i++ )); do
        char=${password:$i:1}
        if [[ $char =~ [a-z] ]]; then
            has_lowercase=1
        elif [[ $char =~ [A-Z] ]]; then
            has_uppercase=1
        elif [[ $char =~ [0-9] ]]; then
            has_number=1
        fi
    done

    # Check if all conditions are satisfied
    if [ "$has_lowercase" -eq 0 ] || [ "$has_uppercase" -eq 0 ] || [ "$has_number" -eq 0 ]; then
        echo "Weak password: Password should contain both alphabet and numeric characters and include both uppercase and lowercase letters."
        return 1
    fi

    return 0
}

# Read file name and password from user
echo "Enter file name:"
read filename
echo "Enter password:"
read -s password

# Validate password
if validate_password "$password"; then
    # Create file
    echo "Creating file $filename.txt"
    touch "$filename.txt"
else
    echo "File not created due to weak password."
fi
