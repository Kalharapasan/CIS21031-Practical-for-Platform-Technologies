#!/bin/bash

# Method to read ten integers from the user
read_integers() {
    echo "Enter ten integers:"
    for (( i=0; i<10; i++ )); do
        read -p "Enter integer $((i+1)): " num
        integers[$i]=$num
    done
}

# Method to sort and display the integers
sort_integers() {
    sorted=($(echo "${integers[@]}" | tr ' ' '\n' | sort -n))
    echo "Sorted integers: ${sorted[*]}"
}

# Method to find smallest and largest integers
min_max_integers() {
    sorted=($(echo "${integers[@]}" | tr ' ' '\n' | sort -n))
    echo "Smallest integer: ${sorted[0]}"
    echo "Largest integer: ${sorted[-1]}"
}

# Method to find duplicated integers
find_duplicates() {
    duplicates=($(echo "${integers[@]}" | tr ' ' '\n' | sort | uniq -d))
    if [ ${#duplicates[@]} -eq 0 ]; then
        echo "No duplicated integers found."
    else
        echo "Duplicated integers: ${duplicates[*]}"
    fi
}

# Method to calculate sum of digits
sum_of_digits() {
    sum=0
    for num in "${integers[@]}"; do
        while [ $num -gt 0 ]; do
            (( sum += num % 10 ))
            (( num /= 10 ))
        done
    done
    echo "Sum of digits: $sum"
}

# Main script
while true; do
    echo "Menu:"
    echo "1. Read ten integers"
    echo "2. Sort and display integers"
    echo "3. Find smallest and largest integers"
    echo "4. Find duplicated integers"
    echo "5. Calculate sum of digits"
    echo "6. Exit"
    read -p "Choose an option: " choice

    case $choice in
        1) read_integers ;;
        2) sort_integers ;;
        3) min_max_integers ;;
        4) find_duplicates ;;
        5) sum_of_digits ;;
        6) echo "Exiting program."; exit 0 ;;
        *) echo "Invalid option. Please choose again." ;;
    esac
    echo
done
