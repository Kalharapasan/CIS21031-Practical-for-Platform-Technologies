#!/bin/bash

read_integers(){
	echo "Enter ten integers :"
	for (( i = 0; i < 10; i++ )); do
		read -p "Enter integers $((i+1)) :" num
		integers[$i]=$num
	done

}

sort_integer(){
	sorted=($(echo "${integers[@]}" | tr '' '\n' | sort -n))
	echo "Sorted integers :${sorted[*]}"
}

min_max_integer(){
	sorted=($(echo "${integers[@]}" | tr ' ' '\n' | sort -n))
	echo "smallest integers :${sorted[0]}"
	echo "largest integers :${sorted[-1]}"
}

find_duplicates(){
	duplicates=($(echo "${integers[@]}" | tr ' ' '\n' | sort | uniq -d))
	if [ ${#duplicates[@]} -eq 0 ]; then
		echo "No duplicated integers found"
	else
		echo "Duplicated integers :${duplicates[*]} "
	fi
}

sum_of_digits(){
	sum=0
	for num in "${integers[@]}";do
		while [ $num -gt 0 ];do
			((sum += num%10))
			((num /= 10))
		done
	done
	echo "Sum of digits :$sum"
}



while true;do
	echo "Menu :"
	echo "1.Read ten integers:"
	echo "2.Short and display integers"
	echo "3.Find smallest and largest integers"
	echo "4.Find duplicated integers"
	echo "5.Calculate sum of digits"
	echo "6.Exit"
	read -p "Choose an option :" choice

	case $choice in
			1)read_integers;;
			2)sort_integer;;
			3)min_max_integer;;
			4)find_duplicates;;
			5)sum_of_digits;;
			6)echo "Exiting program";exit 0;;
			*)echo "Invalid option,Please choose again.";;

	esac
		echo
done