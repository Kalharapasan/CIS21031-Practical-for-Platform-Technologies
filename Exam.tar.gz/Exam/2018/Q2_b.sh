#!/bin/bash

factorial(){
	if (($1 <= 1)); then
		echo 1
	else
		echo $(($1 *$(factorial $(($1 -1))) ))
	fi
}
decimal_to_binary(){
	if (($1 == 0)); then
		echo -n "0"
	elif (($1 == 1)); then
		echo -n "1"
	else
		decimal_to_binary $(( $1 /2))
		echo  -n $(($1 %2))

	fi
}

echo "Menu"
echo "1.Calculate factorial"
echo "2.Convert decimal to binary"
echo "3.exit"

while true; do
	read -p "Choosen an option :" choice

	case $choice in
		1)
			read -p "Enter a number to Calculate factorial :" num
			result=$(factorial $num)
			echo "Factorial : $result"
			;;

		2)
			read -p "Enter a number to Calculate factorial :" num
			result=$(decimal_to_binary $num)
			echo "Factorial : $result"
			;;

		3)
			echo "Exiting program"
			exit 0
			;;
		*)
			echo "Invalid option "
			;;

	esac
	echo

done


