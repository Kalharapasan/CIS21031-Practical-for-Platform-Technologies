#!/bin/bash

# Function to perform file testing operations
file_test_operations() {
    local filename=$1

    # Check if file exists
    if [ -e "$filename" ]; then
        echo "File '$filename' exists."

        # Check if it's a directory
        if [ -d "$filename" ]; then
            echo "'$filename' is a directory."
        else
            echo "'$filename' is not a directory."

            # Check file permissions
            if [ -r "$filename" ]; then
                echo "'$filename' is readable."
            else
                echo "'$filename' is not readable."
            fi

            if [ -w "$filename" ]; then
                echo "'$filename' is writable."
            else
                echo "'$filename' is not writable."
            fi

            if [ -x "$filename" ]; then
                echo "'$filename' is executable."
            else
                echo "'$filename' is not executable."
            fi

            # Check file size
            if [ -s "$filename" ]; then
                echo "'$filename' has size greater than 0."
            else
                echo "'$filename' has size 0."
            fi

            # Check if it's a character special file
            if [ -c "$filename" ]; then
                echo "'$filename' is a character special file."
            else
                echo "'$filename' is not a character special file."
            fi
        fi
    else
        echo "File '$filename' does not exist."
    fi
}

# Read file name from user input
echo "Enter file name:"
read filename

# Call the function with user input
file_test_operations "$filename"
