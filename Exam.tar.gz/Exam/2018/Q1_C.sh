#!/bin/bash

# Function to read 10 integer values from the user and add them to a file
add_integers_to_file() {
    echo "Please enter 10 integer values:"
    for ((i=1; i<=10; i++)); do
        read -p "Enter value $i: " value
        echo $value >> $1
    done
}

# Function to append 10 random integers between 20 to 200 to a file
append_random_integers() {
    for ((i=1; i<=10; i++)); do
        value=$((RANDOM % 181 + 20)) # Generates random integer between 20 to 200
        echo $value >> $1
    done
}

# Check if file exists and is writable
file="fileA.txt"
if [[ -w $file ]]; then
    add_integers_to_file $file
else
    read -p "The file is not writable. Do you want to add write permission? (YES/NO): " answer
    if [[ $answer == "YES" || $answer == "yes" ]]; then
        chmod +w $file
        add_integers_to_file $file
    else
        echo "No content was written to the file."
    fi
fi

# Display file contents line by line
echo "File contents:"
cat $file

# Append 10 random integers to the file
append_random_integers $file

# Calculate the sum of all integers in the file
sum=0
while read -r line; do
    ((sum += line))
done < $file

echo "Sum of all integers in the file: $sum"
