#!/bin/bash

file_operations(){
	echo "Select an option"
	echo "1.List file and directories"
	echo "2.Show hidden files"
	echo "3.Display human -readable sizes of files"
	echo "4.List text and .sh files"

	read -r choice

	case "$choice" in
		1)
		  ls -l
		  ;;
		2)
		   ls -la
		   ;;
		3)
			ls -lh
		   ;;
		4)
			ls  *.txt *.sh
		   ;;

	esac

}

main_menu(){
	echo "Main Menu"
	echo "1.file operations"
	#echo "2.more operations"

	read -r choice

	case "$choice" in
		1)
			file_operations
			;;
		*)
			echo "Invlid option"
			exit 0
			;;
			
	esac		
}


while true; do
	
	echo "Do you want to continume ? (y/n)"
	read answer
	main_menu

	if [[ "$answer" != "y" ]]; then
		break
		
	fi
done

echo "Exiting script ...."