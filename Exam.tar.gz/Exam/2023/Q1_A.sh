#!/bin/bash

function file_operations() {
  echo "Select an option:"
  echo "1) List files and directories"
  echo "2) Show hidden files"
  echo "3) Display human-readable sizes of files"
  echo "4) List text and .sh files"
  # echo "5) Compress a specified folder excluding '.txt' files"  #Functionality not implemented yet
  read -r choice

  case "$choice" in
    1)
      ls -l
      ;;
    2)
      ls -la
      ;;
    3)
      ls -lh
      ;;
    4)
      ls *.txt *.sh
      ;;
    *)
      echo "Invalid option"
      ;;
  esac
}

function main_menu() {
  echo "Main Menu:"
  echo "1) File Operations"
  # echo "2) More options..."  # Add more functionalities here
  read -r choice

  case "$choice" in
    1)
      file_operations
      ;;
    *)
      echo "Invalid option"
      ;;
  esac
}

while true; do
  main_menu
  echo "Do you want to continue? (y/n)"
  read -r answer

  if [[ "$answer" != "y" ]]; then
    break
  fi
done

echo "Exiting script..."
