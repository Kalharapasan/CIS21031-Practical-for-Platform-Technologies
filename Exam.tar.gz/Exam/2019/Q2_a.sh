#!/bin/bash

grading(){

	if (($1  >= 80 && $1  <= 100)); then
		echo "A"
	elif (($1 >= 60 && $1 <= 79 )); then
		echo "B"
	elif (($1 >= 40 && $1 <= 59));then
		echo "C"
	elif (($1 >= 20 && $1 <= 39)); then
		echo "D"
	elif (($1 >=  10 && $1 <= 19));then
		echo "E"
	else
		echo "F"
	fi

}



sum_of_mark(){

	sum=0
	while read mark; do
		sum=$((sum+mark))
	done < mark-sheet
	echo $sum
}

average_of_marks(){

	sum=$(sum_of_mark)
	count=$(wc -l < mark-sheet)
	average=$((sum/count))
	echo $average
}

sort_mark(){
	sort -n mark-sheet > mark-sheet_sorted
	highest=$(tail -n 1 mark-sheet_sorted)
	lowest=$(head -n 1 mark-sheet_sorted)
	echo "Highest Mark : $highest"
	echo "Lowest Mark : $lowest"
}


while true; do

	read -p "Enter Student's mark (0-100) or 'q' to quit : " mark
	
	if [[ $mark == "q" ]]; then
		break
	fi

	if (( $mark >= 0 && $mark <= 100 )); then
		echo $mark >> mark-sheet
		grade=$(grading $mark)
		echo "$mark - $grade " >> mark-grades
	else
		echo "Enter a valid mark."
	fi
done

echo "Grades for each valid mark :"
cat mark-grades
echo "Sum of all marks : $(sum_of_mark)"
echo "Average marks : $(average_of_marks)"
sum_of_mark

rm mark-sheet mark-grades mark-sheet_sorted


