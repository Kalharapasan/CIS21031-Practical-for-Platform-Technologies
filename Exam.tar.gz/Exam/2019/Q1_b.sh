#!/bin/bash


while true; do
	
	read -p "Enter the student index number : " index_number

	echo "Menu"
	echo "1.student Detalis"
	echo "2.Continue"
	echo "3.Exit"

	read -p "Enter you option :" option

	case $option in
		1)
			read  -p "Enter last name :" last_name
			read  -p "Enter registration number :" reg_number
			read  -p "Enter user name :" user_name
			read  -sp "Enter Password : " password
			echo
			read  -sp "Confirm Password : " cPassword
			echo

			while [ "$password" != "$cPassword" ] ;do
				read  -sp "Confirm Password : " cPassword
				echo
			done
			echo "Input data sussesfull"
			echo

			if [[ ! -f "studentinfo,log" ]]; then
			touch studentinfo.log
			chmod +w studentinfo.log

			echo  "##################################################################################" >>studentinfo.log
			echo  "			 		This is Student's details log file                               " >>studentinfo.log
    		echo  "#################################################################################" >>studentinfo.log
			echo  "     The script was run by $user_name on $(date +"%d:%m:%y") at $(date +"%H:%M:%S") " >>studentinfo.log
			echo  "  	The operating system is $(uname) " >>studentinfo.log
    		echo  " 	The working directory is $(pwd) " >>studentinfo.log
			echo  "     Shell Name is $SHELL" >>studentinfo.log
    		echo  "###################################################################################" >>studentinfo.log
			echo  "     Details of the student: $index_number " >>studentinfo.log
			echo  "     Name : $last_name  " >>studentinfo.log
    		echo  " 	RegisIration Number : $reg_number" >>studentinfo.log
    		echo  " 	User Name : $user_name" >>studentinfo.log
    		echo  " 	Passward : $password" >>studentinfo.log

		else
			chmod +w studentinfo.log
			
			echo  "##################################################################################" >>studentinfo.log
			echo  "			 		This is Student's details log file                               " >>studentinfo.log
    		echo  "#################################################################################" >>studentinfo.log
			echo  "     The script was run by $user_name on $(date +"%d") at $(date +"%H:%M:%S") " >>studentinfo.log
			echo  "  	The operating system is $(uname) " >>studentinfo.log
    		echo  " 	The working directory is $(pwd) " >>studentinfo.log
			echo  "     Shell Name is $SHELL" >>studentinfo.log
    		echo  "###################################################################################" >>studentinfo.log
			echo  "     Details of the student: $index_number " >>studentinfo.log
			echo  "     Name : $last_name  " >>studentinfo.log
    		echo  " 	RegisIration Number : $reg_number" >>studentinfo.log
    		echo  " 	User Name : $user_name" >>studentinfo.log
    		echo  " 	Passward : $password" >>studentinfo.log

		fi	



			;;
		2)
			continue
			;;
		3)
			echo "Exiting program."
			exit 0
			;;
		*)
			echo "Invalid option ! Try again"
			;;
	esac
	echo

done