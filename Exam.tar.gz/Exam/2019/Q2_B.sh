#!/bin/bash

# Recursive function to calculate Fibonacci sequence
fibonacci() {
    if (( $1 == 0 )); then
        echo 0
    elif (( $1 == 1 )); then
        echo 1
    else
        echo $(( $(fibonacci $(($1-1))) + $(fibonacci $(($1-2))) ))
    fi
}

# Calculate Fibonacci sequence of 10 numbers
echo "Fibonacci Sequence of 10 numbers:"
for i in {0..9}; do
    echo "$(fibonacci $i)"
done
