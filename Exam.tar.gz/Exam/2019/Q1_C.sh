#!/bin/bash

# Step i: Create Batch directories inside Resources folder on Desktop
mkdir -p ~/Desktop/Resources/Batch_15
mkdir -p ~/Desktop/Resources/Batch_16

# Step ii: List and copy answer scripts to respective Batch directories
echo "Copying answer scripts..."

# List and copy files starting with '15' to Batch_15 directory
echo "Files starting with '15':"
for file in 15*; do
    echo "$file"
    cp "$file" ~/Desktop/Resources/Batch_15/
done
echo "All answer scripts of 15 batch have been successfully copied."

# List and copy files starting with '16' to Batch_16 directory
echo "Files starting with '16':"
for file in 16*; do
    echo "$file"
    cp "$file" ~/Desktop/Resources/Batch_16/
done
echo "All answer scripts of 16 batch have been successfully copied."

# Step iii: Copy Resources folder to directory with Index Number
index_number="ICT001"  # Replace with your Index Number
cp -r ~/Desktop/Resources ~/"$index_number/"

echo "Resources directory is successfully copied."
