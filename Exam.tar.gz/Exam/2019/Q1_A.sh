#!/bin/bash

# Function to check password match
check_password() {
    if [[ "$password" == "$confirm_password" ]]; then
        echo "Passwords Match."
        valid_password=true
    else
        echo "Passwords do not Match."
        valid_password=false
    fi
}

# Main script
while true; do
    read -p "Enter the student Index Number (ex: ICT001, ICT002 etc.): " index_number

    echo "Menu:"
    echo "1. Student Details"
    echo "2. Continue"
    echo "3. Exit"
    read -p "Enter your option: " option

    case $option in
        1)
            read -p "Enter Last Name: " last_name
            read -p "Enter Registration Number: " reg_number
            read -p "Enter User Name: " user_name
            read -sp "Enter Password: " password
            echo
            read -sp "Confirm Password: " confirm_password
            echo
            check_password
            while [ "$valid_password" == false ]; do
                read -sp "Confirm Password: " confirm_password
                echo
                check_password
            done
            ;;
        2)
            continue
            ;;
        3)
            echo "Exiting program."
            exit 0
            ;;
        *)
            echo "Invalid option! Try again."
            ;;
    esac
    echo
done
