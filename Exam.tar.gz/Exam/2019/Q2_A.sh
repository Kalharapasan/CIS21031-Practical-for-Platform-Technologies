#!/bin/bash

# Function to determine grade
grading() {
    if (( $1 >= 80 && $1 <= 100 )); then
        echo "A"
    elif (( $1 >= 60 && $1 <= 79 )); then
        echo "B"
    elif (( $1 >= 40 && $1 <= 59 )); then
        echo "C"
    elif (( $1 >= 20 && $1 <= 39 )); then
        echo "D"
    elif (( $1 >= 10 && $1 <= 19 )); then
        echo "E"
    else
        echo "Invalid"
    fi
}

# Function to calculate sum of valid marks
calculate_sum() {
    sum=0
    while read mark; do
        sum=$(( sum + mark ))
    done < mark-sheet
    echo $sum
}

# Function to calculate average of valid marks
calculate_average() {
    sum=$(calculate_sum)
    count=$(wc -l < mark-sheet)
    average=$(( sum / count ))
    echo $average
}

# Function to sort marks and find highest and lowest
sort_marks() {
    sort -n mark-sheet > mark-sheet_sorted
    highest=$(tail -n 1 mark-sheet_sorted)
    lowest=$(head -n 1 mark-sheet_sorted)
    echo "Highest Mark: $highest"
    echo "Lowest Mark: $lowest"
}

# Main script
while true; do
    read -p "Enter student's marks (0-100) or 'q' to quit: " mark
    if [[ $mark == "q" ]]; then
        break
    fi

    if (( $mark >= 0 && $mark <= 100 )); then
        echo $mark >> mark-sheet
        grade=$(grading $mark)
        echo "$mark - $grade" >> mark-grades
    else
        echo "Enter a valid mark."
    fi
done

# Display grades, sum, average, highest and lowest marks
echo "Grades for each valid mark:"
cat mark-grades
echo "Sum of all marks: $(calculate_sum)"
echo "Average marks: $(calculate_average)"
sort_marks

# Cleanup
rm mark-sheet mark-grades mark-sheet_sorted
