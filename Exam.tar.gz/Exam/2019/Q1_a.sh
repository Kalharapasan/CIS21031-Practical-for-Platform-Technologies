#!/bin/bash

while true; do
	
	read -p "Enter the student index number : " index_number

	echo "Menu"
	echo "1.student Detalis"
	echo "2.Continue"
	echo "3.Exit"

	read -p "Enter you option :" option

	case $option in
		1)
			read  -p "Enter last name :" last_name
			read  -p "Enter registration number :" reg_number
			read  -p "Enter user name :" user_name
			read  -sp "Enter Password : " password
			echo
			read  -sp "Confirm Password : " cPassword
			echo

			while [ "$password" != "$cPassword" ] ;do
				read  -sp "Confirm Password : " cPassword
				echo
			done
			echo "Input data sussesfull"
			;;
		2)
			continue
			;;
		3)
			echo "Exiting program."
			exit 0
			;;
		*)
			echo "Invalid option ! Try again"
			;;
	esac
	echo

done