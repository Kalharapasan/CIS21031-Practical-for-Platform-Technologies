#!/bin/bash

mkdir -p ~/Desktop/Resources/Batch_15
mkdir -p ~/Desktop/Resources/Batch_16

echo "Copying answer secripts"

for file in 15*; do
	echo "$file"
	cp "$file" ~/Desktop/Resources/Batch_15/
done

echo "All answer secripts of 15 batch have benn successfully copied"

echo "Fille staring with '16':"
for file in 16*; do
	echo "$file"
	cp "$file" ~/Desktop/Resources/Batch_16
done
echo "All answer secripts of 16 batch have been successfully copied"


index_number="ICT041"
cp -r ~/Desktop/Resources ~/"$index_number/"
echo "Resources directory is successfully copied"