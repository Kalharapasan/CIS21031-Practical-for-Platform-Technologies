#!/bin/bash

# Function to check and set file permissions for studentinfo.log
set_file_permissions() {
    if [[ ! -f "studentinfo.log" ]]; then
        touch studentinfo.log
    fi

    if [[ ! -w "studentinfo.log" ]]; then
        chmod +w studentinfo.log
    fi
}

# Function to write student details to studentinfo.log
write_to_file() {
    echo "###################################################################################" >> studentinfo.log
    echo "      This is Student's details log file" >> studentinfo.log
    echo "###################################################################################" >> studentinfo.log
    echo "The script was run by $USER on $(date +"%D") at $(date +"%H:%M:%S")" >> studentinfo.log
    echo "The operating system is $(uname)" >> studentinfo.log
    echo "The working directory is $(pwd)" >> studentinfo.log
    echo "Shell Name is $SHELL" >> studentinfo.log
    echo "###################################################################################" >> studentinfo.log
    echo "" >> studentinfo.log
    echo "Details of the student: $index_number" >> studentinfo.log
    echo "Name: $last_name" >> studentinfo.log
    echo "Registration Number: $reg_number" >> studentinfo.log
    echo "User Name: $user_name" >> studentinfo.log
    echo "Password: $password" >> studentinfo.log
    echo "" >> studentinfo.log
}

# Function to check password match
check_password() {
    if [[ "$password" == "$confirm_password" ]]; then
        echo "Passwords Match."
        valid_password=true
    else
        echo "Passwords do not Match."
        valid_password=false
    fi
}

# Main script
while true; do
    set_file_permissions

    read -p "Enter the student Index Number (ex: ICT001, ICT002 etc.): " index_number

    echo "Menu:"
    echo "1. Student Details"
    echo "2. Continue"
    echo "3. Exit"
    read -p "Enter your option: " option

    case $option in
        1)
            read -p "Enter Last Name: " last_name
            read -p "Enter Registration Number: " reg_number
            read -p "Enter User Name: " user_name
            read -sp "Enter Password: " password
            echo
            read -sp "Confirm Password: " confirm_password
            echo
            check_password
            while [ "$valid_password" == false ]; do
                read -sp "Confirm Password: " confirm_password
                echo
                check_password
            done
            write_to_file
            ;;
        2)
            continue
            ;;
        3)
            echo "Exiting program."
            exit 0
            ;;
        *)
            echo "Invalid option! Try again."
            ;;
    esac
    echo
done
